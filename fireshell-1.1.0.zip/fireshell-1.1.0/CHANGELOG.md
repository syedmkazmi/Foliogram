# FireShell Changelog

## 1.1.0 (21 September, 2013)

* Add Roadmap and Contributors to `README.md`
* Move `img`, `css`, `js`, `fonts` folders into new `assets` for tidier scaffolding
* Add `grunt-dev.bat` and `grunt-build.bat` for Windows support double-click commands
* Small `Gruntfile.js` tweaks for `assets` object

## 1.0.0 (15 September, 2013)

* Initial commit
